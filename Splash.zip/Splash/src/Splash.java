import java.awt.Color;

import com.thehowtotutorial.splashscreen.JSplash;

public class Splash {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			JSplash splash = new JSplash(
					Splash.class.getResource("splash.png"), true, true, false,
					"v1.04", null, Color.RED, Color.BLUE);
			splash.splashOn();
			// Call Method;
			splash.setProgress(0, "Initiating");
			Thread.sleep(500);
			splash.setProgress(5, "Initiating");
			Thread.sleep(300);
			splash.setProgress(10, "Initiating");
			Thread.sleep(300);
			splash.setProgress(15, "Initiating");
			Thread.sleep(300);
			splash.setProgress(20, "Initiating");
			Thread.sleep(500);
			splash.setProgress(25, "Loading ICE World");
			Thread.sleep(500);
			splash.setProgress(30, "Loading ICE World");
			Thread.sleep(500);
			splash.setProgress(35, "Loading ICE World");
			Thread.sleep(1000);
			splash.setProgress(40, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(45, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(50, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(55, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(60, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(65, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(70, "Loading ICE World");
			Thread.sleep(200);
			splash.setProgress(75, "Loading ICE World");
			Thread.sleep(1000);
			splash.setProgress(80, "Loading ICE World");
			Thread.sleep(500);
			splash.setProgress(85, "Entering ICE World");
			Thread.sleep(500);
			splash.setProgress(90, "Entering ICE World");
			Thread.sleep(300);
			splash.setProgress(95, "Entering ICE World");
			Thread.sleep(300);
			splash.setProgress(100, "Entering ICE World");
			Thread.sleep(1000);
			splash.splashOff();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
